1.  В домашней директории создать home_works создать директорию
    lesson_10

> mkdir -p \~/home_works/lesson10
>
> ![](./image1.png){width="6.496527777777778in"
> height="1.6444444444444444in"}

2.  В директории lesson_10 создать директорию available, в ней файлы
    app.conf, readme.md, app.log с произвольным содержимым

> ![](./image2.png){width="6.496527777777778in"
> height="1.2715277777777778in"}
>
> ![](./image3.png){width="6.496527777777778in"
> height="1.4458333333333333in"}

3.  В директории lesson_10 создать директорию enabled, в ней создать
    symlink на available/app.conf

> ![](./image4.png){width="6.496527777777778in"
> height="1.7868055555555555in"}
>
> ![](./image5.png){width="6.496527777777778in"
> height="1.40625in"}

4.  В директории lesson_10 создать директории logs и debug; переместить
    файл available/app.log в директорию logs, а в debug сделать hardlink
    на logs/app.log

> ![](./image6.png){width="6.496527777777778in"
> height="2.4743055555555555in"}
>
> ![](./image7.png){width="6.496527777777778in"
> height="2.40625in"}
>
> ![](./image8.png){width="6.496527777777778in"
> height="3.4590277777777776in"}

5.  Добавить к вашей ВМ дополнительный диск.\
    Для VirtualBox инструкция
    [[https://gist.github.com/AnastasiyaGapochkina01/a333559e4910bd85153714de4540ced8]{.underline}](https://gist.github.com/AnastasiyaGapochkina01/a333559e4910bd85153714de4540ced8)

6.  Посмотреть список блочных устройств (lsblk) и список смонтированных
    ФС (df -Th)

> ![](./image9.png){width="6.496527777777778in"
> height="3.3472222222222223in"}
>
> ![](./image10.png){width="6.496527777777778in"
> height="2.0993055555555555in"}

7.  Создать на новом диске ФС типа ext4

> ![](./image11.png){width="6.496527777777778in"
> height="3.7472222222222222in"}

8.  Создать директорию /opt/application и смонтировать в нее новый диск
    (монтирование должно быть постоянным, через /etc/fstab)

> ![](./image12.png){width="6.496527777777778in"
> height="1.4256944444444444in"}
>
> ![](./image13.png){width="6.496527777777778in" height="2.2in"}
>
> ![](./image14.png){width="6.496527777777778in"
> height="2.338888888888889in"}

9.  Скопировать /opt/application все **содержимое** lesson_10.

> sudo cp \~/home_works/lesson10 /opt/application

![](./image15.png){width="6.496527777777778in"
height="2.254861111111111in"}

10. Попробовать сделать hardlink на файл
    \$HOME/home_works/lesson_10/available/readme.md в директории
    /opt/application (не получится); затем сделать symlink на этот же
    файл

![](./image16.png){width="6.496527777777778in" height="0.75625in"}

![](./image17.png){width="6.496527777777778in"
height="2.404861111111111in"}
